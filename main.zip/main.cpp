#include <igl/opengl/glfw/Viewer.h>
#include <iostream>
#include <ostream>
#include <igl/readOFF.h>
#include <igl/doublearea.h>
#include <igl/massmatrix.h>
#include <igl/invert_diag.h>
#include <igl/jet.h>

#include <igl/gaussian_curvature.h>
#include <igl/per_vertex_normals.h>
#include <igl/per_face_normals.h>

#include "HalfedgeBuilder.cpp"



using namespace Eigen; // to use the classes provided by Eigen library
using namespace std;

MatrixXd V;
MatrixXi F;
MatrixXd C(V.rows(), 3);
VectorXd Z;

MatrixXd K; //gaussian curvature
MatrixXd he_K; //gaussian curvature

MatrixXd N_faces;   //computed calling pre-defined functions of LibiGL
MatrixXd N_vertices; //computed calling pre-defined functions of LibiGL


MatrixXd lib_N_vertices;  //computed using face-vertex structure of LibiGL
MatrixXi lib_Deg_vertices;//computed using face-vertex structure of LibiGL

MatrixXd he_face_normal;
MatrixXd he_N_vertices; //computed using the HalfEdge data structure


// This function is called every time a keyboard button is pressed
bool key_down(igl::opengl::glfw::Viewer& viewer, unsigned char key, int modifier){
	switch(key){
		case '1':
			viewer.data().set_normals(N_faces);
			return true;
		case '2':
			viewer.data().set_normals(N_vertices);
			return true;
		case '3':
			viewer.data().set_normals(lib_N_vertices);
			return true;
		case '4':
			viewer.data().set_normals(he_N_vertices);
			return true;
		case '5':
			viewer.data().set_data(K);
			return true;
		case '6':
			viewer.data().set_data(he_K);
			return true;

		default: break;
	}
	return false;
}

	/**
	 * Return the degree of a given vertex 'v'
   * Exercice
	 **/
	int vertexDegree(HalfedgeDS he, int v) {
	 	// TO BE COMPLETED
		int count = 0;
		int edge = he.getEdge(v);
		int oppEdge = he.getOpposite(edge);
		int prevEdge = he.getPrev(oppEdge);
		count++;

		while (prevEdge != edge) {
			oppEdge = he.getOpposite(prevEdge);
			prevEdge = he.getPrev(oppEdge);
			count++;
		}
		

	return count;
	}




	/**
         * Return the degree of a given vertex 'v'
   * Turn around vertex 'v' in CCW order
         **/
// int vertexDegreeCCW(HalfedgeDS he, int v)
// {
//         // TO BE COMPLETED
//         
//         return 0;
// }



		/**
	 * Compute the vertex normals (he)
   * Exercice
	 **/
	
	void vertexNormals(HalfedgeDS he) {
		
		he_N_vertices = MatrixXd::Zero(V.rows(), 3);
		Vector3d V1, V2, V3;
		int v2, v3;
		for (int v = 0; v < V.rows(); v = v + 1) {
			
			int edge = he.getEdge(v);
			int oppEdge = he.getOpposite(edge);
			int prevEdge = he.getPrev(oppEdge);
			if (he.getFace(oppEdge) != -1) {
				v2 = he.getTarget(oppEdge);
				v3 = he.getTarget(he.getOpposite(prevEdge));
				V1 << V(v, 0), V(v, 1), V(v, 2);
				V2 << V(v2, 0), V(v2, 1), V(v2, 2);
				V3 << V(v3, 0), V(v3, 1), V(v3, 2);
				he_N_vertices.row(v) += (V2-V1).cross(V3-V1);
			}

			while (prevEdge != edge) {
				oppEdge = he.getOpposite(prevEdge);
				prevEdge = he.getPrev(oppEdge);
				if (he.getFace(oppEdge) != -1) {
					v2 = he.getTarget(oppEdge);
					v3 = he.getTarget(he.getOpposite(prevEdge));
					V1 << V(v, 0), V(v, 1), V(v, 2);
					V2 << V(v2, 0), V(v2, 1), V(v2, 2);
					V3 << V(v3, 0), V(v3, 1), V(v3, 2);
					he_N_vertices.row(v) += (V2 - V1).cross(V3 - V1);
				}
				
			}
			
	    }
		he_N_vertices.rowwise().normalize();
		
	 	
	 }

		// Compute lib_per-vertex normals
		/**
			 * Compute the vertex normals (global, using libiGl data structure)
   * Exercice
	 **/
	void lib_vertexNormals() {
		lib_N_vertices = MatrixXd::Zero(V.rows(), 3);
		MatrixXd lib_face_normal = MatrixXd::Zero(F.rows(), 3);
		Vector3d V1, V2, V3;
		int count = 0; //count the number of neighbour faces for each vertex
		std::map<int, std::vector<int>> mapOfFaces; //map <vertex, vector of neighbourfaces>
		
		for (int i = 0; i < V.rows(); i = i + 1) {
			mapOfFaces.insert({ i,std::vector<int>{} });
		}

		for (int i = 0; i < F.rows(); i = i + 1) {
			V1 << V(F(i, 0), 0), V(F(i, 0), 1), V(F(i, 0), 2);
			V2 << V(F(i, 1), 0), V(F(i, 1), 1), V(F(i, 1), 2);
			V3 << V(F(i, 2), 0), V(F(i, 2), 1), V(F(i, 2), 2);

			lib_face_normal.row(i)= ((V3 - V1).cross(V3 - V2));
			lib_N_vertices.row(F(i, 0)) += lib_face_normal.row(i);
			lib_N_vertices.row(F(i, 1)) += lib_face_normal.row(i);
			lib_N_vertices.row(F(i, 2)) += lib_face_normal.row(i);
		}
		lib_N_vertices.rowwise().normalize();
	}


	/**
	 * Return the number of occurrence of vertex degrees: for d=3..n-1
   * Exercice
	 **/
	void vertexDegreeStatistics(HalfedgeDS he) {
	std::cout << "Computing vertex degree distribution...";
	
	MatrixXi occ = MatrixXi::Zero(V.rows(), 1);
	for (int v = 0; v < V.rows(); ++v) {
		int degree = vertexDegree(he, v);
		
		occ(degree,0)++;
	}
	// auto start = std::chrono::high_resolution_clock::now(); // for measuring time performances
	/*
	for (int i = 0; i < he.sizeOfVertices() - 1; ++i) {
		std::cout << "number of degrees = "<<i << " is "<< occ[i] <<std::endl;
	}
	*/
	}




	void lib_vertexDegrees() {
		lib_Deg_vertices = MatrixXi::Zero(V.rows(), 1);
		for (int i = 0; i < F.rows(); i = i + 1) {
			lib_Deg_vertices(F(i, 0),0) += 2;
			lib_Deg_vertices(F(i, 1), 0) += 2;
			lib_Deg_vertices(F(i, 2), 0) += 2;
		}
	}
        
	/**
	 * Return the number of boundaries of the mesh
   * Exercice
	 **/
// int countBoundaries(HalfedgeDS he){
// 	// TO BE COMPLETED

// 	return 0;
// }
	double distance(MatrixXd& V1, MatrixXd& V2) {
		return (V2 - V1).norm();
	}

	double cosinus_law(double a, double b, double c) {
		return acos((-pow(c, 2) + pow(a, 2) + pow(b, 2)) / (2.0 * a * b));
	}

	double cotangent(double i) { return(1 / tan(i)); }
	
	MatrixXd internal_angles() {
		MatrixXd angles(F.rows(), 3);
		double a = 0, b = 0, c = 0;
		MatrixXd A(1, 3), B(1, 3), C(1, 3);
		for (int i = 0; i < F.rows(); i = i + 1) {
			A = V.row(F(i, 0));
			B = V.row(F(i, 1));
			C = V.row(F(i, 2));

			a = distance(C, B);
			b = distance(A, C);
			c = distance(A, B);



			angles(i, 0) = cosinus_law(c, b, a);
			angles(i, 1) = cosinus_law(a, c, b);
			angles(i, 2) = cosinus_law(a, b, c);

		}

		return angles;
	}
	
//after looking to the code in the predefined function in libigl I noticed that the gaussian curvatures are not normalized by the voronoi region
//so this comparaison is not very precise

	void he_gaussian_curvature(HalfedgeDS he) {
		double a = 0, b = 0, c = 0, a1 = 0, b1 = 0, Avoronoi = 0;
		int edge=0, oppEdge=0, prevEdge=0, edge1=0, vNext=0, _vNext=0;
		he_K = MatrixXd::Zero(V.rows(), 1);
		Vector3d AB, AC;
		MatrixXd angleDeficit=MatrixXd::Zero(V.rows(),1);
		MatrixXd dualCell= MatrixXd::Zero(V.rows(), 1);;
		MatrixXd A(1, 3), B(1, 3), C(1, 3);
		for (int v=0; v < V.rows(); v = v + 1) {
			
			edge = he.getEdge(v);
			oppEdge = he.getOpposite(edge);
			prevEdge = he.getPrev(oppEdge);
			edge1 = he.getOpposite(prevEdge);

			vNext = he.getTarget(oppEdge);
			_vNext = he.getTarget(edge1);
			
			A << V(v, 0), V(v, 1), V(v, 1);
			B << V(_vNext, 0), V(_vNext, 1), V(_vNext, 1);
			C << V(vNext, 0), V(vNext, 1), V(vNext, 1);


			a = distance(A, C);
			b = distance(B, C);
			c = distance(A, B);


			double beta0 = cosinus_law(a, c, b);
			double beta1 = cosinus_law(b, c, a);
			double beta2 = cosinus_law(a, b, c);


			if ((beta0 > 3.14) || (beta1 > 3.14) || (beta2 > 3.14)) {
				if (beta0 > 3.14) {
					AB << V(vNext, 0) - V(v, 0), V(vNext, 1) - V(v, 1), V(vNext, 2) - V(v, 2);
					AC << V(_vNext, 0) - V(v, 0), V(_vNext, 1) - V(v, 1), V(_vNext, 2) - V(v, 2);
					dualCell(v, 0) += 0.25 * AB.cross(AC).norm();
				}
				else {
					dualCell(v,0)+= (1/8.0) * AB.cross(AC).norm();
				}
			}
			else {
				dualCell(v, 0) += (1 / 8.0) * (pow(c, 2) * cotangent(beta1) + pow(a, 2) * cotangent(beta2));
			}


			

			dualCell(v, 0) += 0.5 * ((AB * 0.5).cross(AC * 0.5).norm());
			
			
			//angles for angleDeficit
			
			angleDeficit(v, 0) += beta0;
			


			while (prevEdge != edge) {
				
				oppEdge = he.getOpposite(prevEdge);
				prevEdge = he.getPrev(oppEdge);
				edge1 = he.getOpposite(prevEdge);

				vNext = he.getTarget(oppEdge);
				_vNext = he.getTarget(edge1);

				A << V(v, 0), V(v, 1), V(v, 1);
				B << V(_vNext, 0), V(_vNext, 1), V(_vNext, 1);
				C << V(vNext, 0), V(vNext, 1), V(vNext, 1);


				a = distance(A, C);
				b = distance(B, C);
				c = distance(A, B);


				double beta0 = cosinus_law(a, c, b);
				double beta1 = cosinus_law(b, c, a);
				double beta2 = cosinus_law(a, b, c);


				if ((beta0 > 3.14) || (beta1 > 3.14) || (beta2 > 3.14)) {
					if (beta0 > 3.14) {
						AB << V(vNext, 0) - V(v, 0), V(vNext, 1) - V(v, 1), V(vNext, 2) - V(v, 2);
						AC << V(_vNext, 0) - V(v, 0), V(_vNext, 1) - V(v, 1), V(_vNext, 2) - V(v, 2);
						dualCell(v, 0) += 0.25 * AB.cross(AC).norm();
					}
					else {
						dualCell(v, 0) += (1 / 8.0) * AB.cross(AC).norm();
					}
				}
				else {
					dualCell(v, 0) += (1 / 8.0) * (pow(c, 2) * cotangent(beta1) + pow(a, 2) * cotangent(beta2));
				}




				dualCell(v, 0) += 0.5 * ((AB * 0.5).cross(AC * 0.5).norm());


				//angles for angleDeficit

				angleDeficit(v, 0) += beta0;
			}

			angleDeficit(v, 0)=2 * 3.14-angleDeficit(v, 0);
			
			he_K(v, 0) = angleDeficit(v, 0) / dualCell(v, 0);

		}
	}


		



// ------------ main program ----------------
int main(int argc, char *argv[]) {

//	if(argc<2) {
//		std::cout << "Error: input file required (.OFF)" << std::endl;
//		return 0;
//	}
//	std::cout << "reading input file: " << argv[1] << std::endl;

//	igl::readOFF(argv[1], V, F);
        igl::readOFF("../data/cat0.off",V,F);

	//print the number of mesh elements
        //std::cout << "Points: " << V.rows() << std::endl;
		std::cout << "zall4" << std::endl;

       HalfedgeBuilder* builder=new HalfedgeBuilder();  //

       HalfedgeDS he=builder->createMesh(V.rows(), F);  //

	//compute vertex degrees
    


	

   
	cout << "Counting vertexDegree using halfedge...";
	auto start = std::chrono::high_resolution_clock::now(); // for measuring time performances
	
	vertexDegreeStatistics(he);

	auto finish = std::chrono::high_resolution_clock::now();
	std::chrono::duration<double> elapsed = finish - start;
	std::cout << "Done in" << elapsed.count() << " s\n";
    
	cout << "Counting vertexDegree using libigl data structure...";
	start = std::chrono::high_resolution_clock::now(); // for measuring time performances
	
	lib_vertexDegrees();

    finish = std::chrono::high_resolution_clock::now();
	elapsed = finish - start;
	std::cout << "Done in" << elapsed.count() << " s\n";

	// compute number of boundaries
        //int B=countBoundaries(he);  //
        //std::cout << "The mesh has " << B << " boundaries" << std::endl;//

	// Compute normals

	// Compute per-face normals
	
	//initializing N_vertices 


	
	cout << "Counting Normals per vertex using predefined functions...";
	start = std::chrono::high_resolution_clock::now(); // for measuring time performances
	igl::per_face_normals(V,F,N_faces);


	// Compute per-vertex normals
	igl::per_vertex_normals(V,F,N_vertices);

	finish = std::chrono::high_resolution_clock::now();
	elapsed = finish - start;
	std::cout << "Done in" << elapsed.count() << " s\n";


	// Compute lib_per-vertex normals
	cout << "Counting Normals per vertex using libigl's data structure...";
	start = std::chrono::high_resolution_clock::now(); // for measuring time performances
	
	lib_vertexNormals();

	finish = std::chrono::high_resolution_clock::now();
	elapsed = finish - start;
	std::cout << "Done in" << elapsed.count() << " s\n";


	// Compute he_per-vertex normals
	cout << "Counting Normals per vertex using half edge ...";
	start = std::chrono::high_resolution_clock::now(); // for measuring time performances
	
	vertexNormals(he);  

	finish = std::chrono::high_resolution_clock::now();
	elapsed = finish - start;
	std::cout << "Done in" << elapsed.count() << " s\n";


	cout << "calculating gaussian curvature per vertex using predefined functions ...";
	start = std::chrono::high_resolution_clock::now(); // for measuring time performances
	
	igl::gaussian_curvature(V, F, K);
	
	finish = std::chrono::high_resolution_clock::now();
	elapsed = finish - start;
	std::cout << "Done in" << elapsed.count() << " s\n";


	cout << "calculating gaussian curvature per vertex using half edge ...";
	
	start = std::chrono::high_resolution_clock::now(); // for measuring time performances
	he_gaussian_curvature(he);
	
	finish = std::chrono::high_resolution_clock::now();
	elapsed = finish - start;
	std::cout << "Done in" << elapsed.count() << " s\n";

 ///////////////////////////////////////////

  // Plot the mesh with pseudocolors
  igl::opengl::glfw::Viewer viewer; // create the 3d viewer

  viewer.callback_key_down = &key_down;
  viewer.data().show_lines = false;
  viewer.data().set_mesh(V, F);  //
  viewer.data().set_normals(N_faces);  //
  std::cout<<
    "Press '1' for per-face normals calling pre-defined functions of LibiGL."<<std::endl<<
	"Press '2' for per-vertex normals calling pre-defined functions of LibiGL."<<std::endl<<
    "Press '3' for lib_per-vertex normals using face-vertex structure of LibiGL ."<<std::endl<<
	"Press '4' for HE_per-vertex normals using HalfEdge structure."<<std::endl<<
    "Press '5' for per-vertex curvature using pre-defined functions." << std::endl<<
    "Press '6' for HE_per-vertex curvature using HalfEdge structure." << std::endl;
 
  

  
  
	Z.setZero(V.rows(),1);

//  Z colors
   // Use the z coordinate as a scalar field over the surface

	Z = V.col(2);

	
  // Assign per-vertex colors
	igl::jet(Z,true,C);



	viewer.data().set_colors(C);  // Add per-vertex colors
	
	
	

  //viewer.core(0).align_camera_center(V, F);  //not needed
	viewer.launch(); // run the viewer
}
